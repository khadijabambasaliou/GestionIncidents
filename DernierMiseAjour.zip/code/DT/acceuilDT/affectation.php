<?php
session_start();
 $email=$_SESSION['email'] ;
 $idUser=$_SESSION['idUser'];
?>


<html>
<head>
 <!-- Google Fonts -->
 <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="assets/vendor/aos/aos.css" rel="stylesheet">
<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
<link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<link rel="stylesheet" href="Navbar/styleNavbar.css">



<!-- Template Main CSS File -->
<link href="assets/css/style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">



<style>

      #formback{
        margin-top:100px;
        margin-left: 300px;
        width: 1050px; 
        background-color: FFFFFF;
        height:600px;  
        position: absolute;
      }
    
#affecter{
        color:FFFFFF;
        background-color: #4d9d2a;
        width:200px;
        border-radius:2rem;
        font-weight: bold;
        margin-left: 600px;
      }


    </style>

</head>
<body style="font-family: 'Roboto';">
<div class="container" id="formback">
           <?php

                                    include ("connect_BD.php");                     
                                    if(!empty($_POST['affectation'])) 
                                    {   
                                       $affectation=$_POST['affectation'];
                                      $id=$_GET['idIncident'];  

                                       $requ=$con->query("select * from User where prenomUser='$affectation'");
                                      while($row=$requ->fetch()){
                                          $idi=$row['idUser'];
                                      }
      
                                       
                                        if($affectation !="choisissez")
                                        {
                                            $req="update Incident set ingenieurAffecte='$affectation',statusIncident='encours',idUser='$idi' where idIncident='$id'" ;
                                            $res= $con->prepare($req);
                                            $res-> execute();
                                            header('Location: index.php');
                                        }
                                    }
                    ?>
     
       <hr style="height: 5px;">
       <div style="margin-left : 100px; margin-top :10px; position:absolute;">

                    <table >
                            <tbody>
                            <?php
                                            include ("connect_BD.php");
                                            $id=$_GET['idIncident'];
                                            $req=$con->query("select *  from Incident where idIncident='$id' ");
                            while($row = $req->fetch(PDO::FETCH_ASSOC)) :
                            ?>
                                <tr><td style="font-size:20px; color:#4d9d2a; font-weight: bold; padding: 10px;">Incident  :</td><td style="font-size:20px;font-weight: bold;"><?php echo htmlspecialchars($row['intituleIncident']); ?></td></tr>
                                <tr><td></td><td style="font-size:15px; color:#6d6e72; font-weight: bold; padding:5px">Description : </td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['descriptionIncident']); ?></td></tr>
                                <tr><td></td><td style="font-size:15px; color:#6d6e72; font-weight: bold; padding:5px">Equipement Concerné : </td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['equipementConcerne']); ?></td></tr>
                                <tr><td></td><td style="font-size:15px; color:#6d6e72; font-weight: bold; padding:5px">Catégorie : </td>
                                        <td style="font-weight: bold; ">                         
                                               <form method="post" action="">
                                      <select class="form-select" aria-label="Default select example" name="changementC" type="text" style="width: 130px;  border-color: #4d9d2a; border-width:2px; border-radius: 0.5rem;">
                                                <option selected><?php echo htmlspecialchars($row['categorieIncident']); ?></option>
                                                <option value="Materiel">materiel</option>
                                                <option value="Logiciel">Logiciel</option>
                                                <option value="Licence">Licence</option>
                                          </select>
                                        </td></tr>
                                <tr><td></td><td style="font-size:15px; color:#6d6e72; font-weight: bold; padding:5px">Date de creation de l'incident :  </td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['dateCreationIncident']); ?></td></tr>
                                <tr><td></td><td style="font-size:15px; color:#6d6e72; font-weight: bold; padding:5px">Niveau de criticité : </td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['niveauCriticite']); ?></td></tr>
                                <tr><td></td><td style="font-size:15px; color:#6d6e72; font-weight: bold;  padding:5px">Ingénieur assigné : </td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['ingenieurAffecte']); ?></td></tr>
                                <?php  endwhile; ?>

                            </tbody>
                    </table>
            <br>
           
            <?php
                                            include ("connect_BD.php");  
                                           if(isset($_POST['changementC']))
                                           {  
                                                $categorie=$_POST['changementC'];
                                                $idincident=$_GET['idIncident'];
                                                    $req="update Incident set categorieIncident='$categorie' where idIncident='$idincident'" ;
                                                    $res= $con->prepare($req);
                                                    $res-> execute();  
                                           }                                                     
                           ?>
         
                    <label style="margin-left:10px; font-weight: bold;">Affecter à :</label>
                    <select class="form-select" aria-label="Default select example" name="affectation" type="text" style="width: 300px; margin-left:200px;  border-color: #4d9d2a; border-width:2px; border-radius: 0.5rem;">
                      <option selected disabled>choisissez</option>
                      <option value="Birane">Birane</option>
                      <option value="Khadim">khadim </option>
                      <option value="AWA">AWA</option>
                      <option value="Bamba">Bamba</option>
                      <option value="Khadija">Khadija</option>
                      <option value="Mame Diarra">Mame Diarra</option>
                </select> 

                <div style="margin-top: 70px;">  
                <i class="bi bi-arrow-left-circle-fill" style="font-size: 30px; color:#4d9d2a; margin-right:10px; "></i><a href="index.php" style="font-size: 30px; color:#4d9d2a; ">Retour</a>
               <button  type="submit" class="btn btn-secondary button " id="affecter" name="affect"> Affecter Incident</button>  
                </div>   
                            </form>
        </div>
</div>
<header  style="position:fixed;">
            <div class="header-item">
            <img src="Navbar/logo.png" alt="logo" class="logo-head">
                <ul >
                    <li class="profil">
                            <i class="far fa-user navbar-icon-head"></i>
                        <span class="navbar-title-head">
                        <?php
                            include ("connect_BD.php");
                            $rep=$con->query("select  nomUser,prenomUser from User where idUser='$idUser'");
                            while($row=$rep->fetch()){
                                echo $row['prenomUser']." ".$row['nomUser'];
                            }
                        ?>
                        </span>
                    </li>
                </ul>
            </div>
        </header>
        <nav class="navbar" style="position:fixed;">
            <ul class="navbar-menu">
                <li class="navbar-items logo">
                    <a href="#" class="navbar-link">
                        <span class="navbar-title">
                        <?php
                            include ("connect_BD.php");
                            $rep=$con->query("select  nomUser,prenomUser from User where idUser='$idUser'");
                            while($row=$rep->fetch()){
                                echo $row['prenomUser']." ".$row['nomUser'];
                            }
                        ?>
                        </span>
                        <i class="fas fa-chevron-right navbar-icon"></i>    
                    </a>
                </li>
                <li class="navbar-items">
                    <a href="index.php" class="navbar-link">
                        <i class="fas fa-home navbar-icon"></i>
                        <span class="navbar-title">Accueil</span>
                    </a>
                </li>
                <li class="navbar-items">
                    <a href="rechercher.php" class="navbar-link">
                        <i class="fas fa-search navbar-icon"></i>
                        <span class="navbar-title">Rechercher</span>
                    </a>
                </li>
                <!-- <li class="navbar-items">
                    <a href="#" class="navbar-link">
                        <i class="fas fa-edit navbar-icon"></i>
                        <span class="navbar-title">Créer incident</span>
                    </a>
                </li>-->
                <li class="navbar-items">
                    <a href="formCI.php" class="navbar-link">
                        <i class="fas fa-ticket-alt navbar-icon"></i>
                        <span class="navbar-title">incident à affecter</span>
                    </a>
                </li> 
                <li class="navbar-items">
                    <a href="#" class="navbar-link">
                        <i class="fas fa-chart-line navbar-icon"></i>
                        <span class="navbar-title">Statistiques</span>
                    </a>
                </li>
                <li class="navbar-items">
                    <a href="../index.php" class="navbar-link">
                        <i class="fas fa-sign-out-alt navbar-icon"></i>
                        <span class="navbar-title">Deconnexion</span>
                    </a>
                </li>
            </ul>
        </nav>


        


</body>
    </html>

