<?php
session_start();
 $email=$_SESSION['email'] ;
 $idClient=$_SESSION['idClient'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Client</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/sesam.png" rel="icon">
  <link href="assets/img/sesam.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="styles.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">



  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">


</head>

<body>
  <div style="margin-left : 320px; margin-top :160px; position:absolute;">
  <?php
            include ("connect_BD.php");
           $req=$con->query("select * from Incident where idClient='$idClient' order by  dateCreationIncident desc");
         
          $chaine="
            <table border='2px' width='135%'><tr><th bgcolor='#4D9D2A'>ID incident</th><th bgcolor='#4D9D2A'>Intitulé de l'incident</th><th bgcolor='#4D9D2A'>Date de creation</th><th bgcolor='#4D9D2A'>Status</th><th bgcolor='#4D9D2A'>Ingénieur Assigné</th><th bgcolor='#4D9D2A'>Action</th></tr>";
            while($ligne=$req->fetch()){
               $chaine=$chaine."<tr>
               <td>".$ligne['idUnique']."</td>
               <td>".$ligne['intituleIncident']."</td>
               <td>".$ligne['dateCreationIncident']."</td>
               <td>".$ligne['statusIncident']."</td>
               <td>".$ligne['ingenieurAffecte']."</td>
               <td><a href='details.php?idIncident=".$ligne['idIncident']."' target='_self'>Details</a></td>
               </tr>";

            }
          $chaine=$chaine."</table>";
          echo $chaine;
          ?>
          
  </div>

  <!-- ======= Mobile nav toggle button ======= -->
  <i class="bi bi-list mobile-nav-toggle d-xl-none"></i>

  
  <div class="verte"></div>
          <div  class="input-group rounded">
                        
                            <img src="../../images/sesam.png" class="image1">
                      
              <input type="search" class="form-control rounded" placeholder="Search" aria-label="Search"
                aria-describedby="search-addon" id="recherche" />
              <span class="input-group-text border-0" id="iconeR">
                <i class="fas fa-search" ></i>
              </span>                               
        </div>
<div>

    <div id="VI">
    <button  type="submit" class="btn btn-secondary button "  id="CI"> Creer un incident</button>  
          <p>Vos Incidents</p>           
    </div>
</div>


                 
                                 
            



<!-- ======= Header ======= -->


  <header id="header">
    <div class="d-flex flex-column">
      <div class="profile">
       
       <div class="icone1"><?php
                    $con = new PDO('mysql:host=localhost;dbname=Gestion_Incidents', 'root', 'dija98');
                    $rep=$con->query("select image from image where idClient='$idClient'");
                    while($row=$rep->fetch()){
                     echo '<img  style=" width: 100px;height: 100px;  border-radius:2rem;  margin-bottom:30px; margin-top: 60px; margin-left: 12px;  " src="'.$row['image'].'" >';
                    }

      ?>
      
      </div>
      <nav id="navbar" class="nav-menu navbar" style="height: 350px;">
        <ul>
          <li><a href="index.php" class="nav-link scrollto active"><i class="bx bx-home"></i> <span>Acceuil</span></a></li>
          <li><a href="#" class="nav-link scrollto"><i class="bi bi-search"></i> <span>Rechercher</span></a></li>
          <li><a href="formCI.php" class="nav-link scrollto" target="_self"><i class="bi bi-pencil-square"></i><span>Creer incident</span></a></li>
          <li><a href="../index.php" class="nav-link scrollto"><i class="bi bi-power"></i> <span>Déconnexion</span></a></li>
        </ul>
      </nav><!-- .nav-menu -->
    </div>
  </header><!-- End Header -->
                          
<!-- Remove the container if you want to extend the Footer to full width. -->
<div id="div1">

  <footer class="bg-light text-center text-white">
   <!-- Copyright -->
  <div class="text-center" style="background-color: #4d9d2a; height: 45px; font-weight:bold;">
    © 2021 All Rigths Reserved  

      <!-- Facebook -->
      <a
        class="btn btn-primary btn-floating m-1"
        style="background-color: #3b5998;    border-radius: 1.1rem; right: 300px; position:absolute; "
        href="#!"
       ><i class="fab fa-facebook-f"></i></a>

      <!-- Twitter -->
      <a
        class="btn btn-primary btn-floating m-1"
        style="background-color: #55acee;     border-radius: 1.1rem; right: 250px; position:absolute;"
        href="#!"
        role="button"
        ><i class="fab fa-twitter"></i></i
      ></a>


      <!-- Instagram -->
      <a
        class="btn btn-primary btn-floating m-1"
        style="background-color: #ac2bac;     border-radius: 1.1rem; right: 200px; position:absolute;"
        href="#!"
        role="button"
        ><i class="fab fa-instagram"></i
      ></a>

      <!-- Linkedin -->
      <a
        class="btn btn-primary btn-floating m-1"
        style="background-color: #0082ca;     border-radius: 1.1rem; right: 150px; position:absolute;"
        href="#!"
        role="button"
        ><i class="fab fa-linkedin-in"></i
      ></a>
      <!-- Github -->
      <a
        class="btn btn-primary btn-floating m-1"
        style="background-color: #333333;  border-radius: 1.1rem; right: 100px; position:absolute;"
        href="#!"
        role="button"
        ><i class="fab fa-github"></i
      ></a>

  </div>
  <!-- Copyright -->
</footer>
  
</div>
<!-- End of .container -->

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/typed.js/typed.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>