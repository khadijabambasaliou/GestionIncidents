<?php
session_start();
 $email=$_SESSION['email'] ;
 $idClient=$_SESSION['idClient'];
 $mot = $_SESSION['nomClient'];

 use PHPMailer\PHPMailer\PHPMailer;
 use PHPMailer\PHPMailer\SMTP;
 use PHPMailer\PHPMailer\Exception;
 
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

?>


<html>
<head>
 <!-- Google Fonts -->
 <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="assets/vendor/aos/aos.css" rel="stylesheet">
<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
<link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">



<!-- Template Main CSS File -->
<link href="assets/css/style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">



<style>


      #formCI
      {
        margin-left: 150px;
        margin-top:50px;
        width: 750px; 
        background-color: #F1F6F0 ;
        height: 500px;  
        position: absolute;
        opacity: 0.8;
        border-radius: 1.1rem;
      }
      #formback{
        margin-left: 300px;
        width: 1050px; 
        background-color: #9DAA9A;
        height:600px;  
        position: absolute;
      }
      .navbar{
width: 100%;
height: 8%;
margin: auto;
display: flex;
align-items: center;
background-color: #fcfcfc;
}

    </style>

</head>
<body>
<?php
                    include ("connect_BD.php");                     
                      if(!empty($_POST['intituleIncident']) && !empty($_POST['equipementConcerne']) && !empty($_POST['categorieIncident']) && !empty($_POST['niveauCriticite']) && !empty($_POST['descriptionIncident'])) 
                      {    
                  $incident=$_POST['intituleIncident'];
                  $description =$_POST['descriptionIncident'];
                  $categorie =$_POST['categorieIncident'];
                 
                  $criticite=$_POST['niveauCriticite'];
                  $equipement=$_POST['equipementConcerne'];
                  $status="cree";
                  $ingenieur="Aucun";
                  $date = date('y-d-m h:i:s');

                  $mots = substr($mot,0,2);
                    $day = date('mdy ');
                    $mo=$mots.$day;

                  $idUnique=bin2hex($mo);
                  $dateCloture=date('y-d-m h:i:s');
                  $idClient=$_SESSION['idClient'];

                  switch($_POST['niveauCriticite'])
                  {
                      case 0 :
                                $criticite ="Mineur";break;
                      case 1: 
                                $criticite ="Majeur";break;
                       case 2: 
                                $criticite="Critique";break;
                    default:
                            $criticite ="Autre";
                  }
            $req="insert into Incident(idClient,intituleIncident,categorieIncident,descriptionIncident,dateCreationIncident,statusIncident,equipementConcerne,niveauCriticite,ingenieurAffecte,idUnique,dateClotureIncident)
            values('$idClient','$incident','$categorie','$description','$date','$status','$equipement','$criticite','$ingenieur','$idUnique','$dateCloture')";
            $res= $con->prepare($req);
            $res-> execute(); 

                } 
      ?>
               
<div class="container" id="formback">
    <div class="" id="formCI">
                <h2 style="text-align: center; margin-top:10px; color:#9DAA9A;">Creer votre incident </h2>
    <div class="col" >
             <form action="" method="post">
                  <label style="margin-left:10px;  font-weight: bold;">Intitulé de l'incident :</label>
                    <input type="text" class="form-control" name="intituleIncident" style="width: 400px; margin-left:170px;  border-color: #4d9d2a; border-width:2px; border-radius: 0.5rem;">
                    <label style="margin-left:10px;font-weight: bold;">Descrivez-nous votre probléme :</label>
                  <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" type="text" name="descriptionIncident"style="width:400px;margin-left:170px; border-color: #4d9d2a;border-width:2px; border-radius: 0.5rem;"></textarea>
                  <label style="margin-left:10px; font-weight: bold;">Equipement concerné:</label>
                  <select class="form-select" aria-label="Default select example" name="equipementConcerne" type="text" style="width: 300px; margin-left:200px;  border-color: #4d9d2a; border-width:2px; border-radius: 0.5rem;">
                      <option selected>Open this select menu</option>
                      <option value="switch">switch</option>
                      <option value="modem">modem</option>
                      <option value="routeur">routeur</option>
                      <option value="ordinateur">ordinateur</option>
                      <option value="autre">Autre</option>
                  </select>
                  <label style="margin-left:10px; font-weight: bold;">Catégorie d'incident:</label>
                  <select class="form-select" aria-label="Default select example" type="text" name="categorieIncident" style="width: 300px; margin-left:200px;  border-color: #4d9d2a; border-width:2px; border-radius: 0.5rem;">
                      <option selected>Open this select menu</option>
                      <option value="logiciel">logiciel</option>
                      <option value="materiel">materiel</option>
                      <option value="reseau">reseau</option>
                      <option value="autre">Autre</option>
                  </select>
                  <label  style="margin-left:10px; font-weight: bold;">Niveau de criticité :</label>
                 <p style="margin-left:150px;"> Mineur  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Majeur    
                 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Critique</p>
                  <input type="range" class="form-range" min="0" max="2" step="1"  name="niveauCriticite" id="customRange3" style="width: 400px; margin-left:150px;  ">
                  <button  type="submit" class="btn btn-secondary button" name="valide" style="margin-left:80px; background-color: #4d9d2a; height: 35px; width: 80px;border-radius:0.9rem;" > Creer</button>  
                  <p class="box-register" ><a href="index.php" style="color: #4d9d2a;font-weight:bold;margin-left:20px; font-size :18px;">Annuler</a></p>
          </form>
          <?php

              $emetteur = $_SESSION['email'];
              $sujet = "test1";
              $message ="Nous vous communiquons qu'un nouveau incident a été crée.";
              $recepteur ="kanekhadijasaliou@gmail.com";

              if($_POST['valide'])
              {
                function sendmail($emetteur,$sujet,$message,$recepteur)

                {
                 //Create an instance; passing `true` enables exceptions
                 $mail = new PHPMailer(true);
                 
                 try {
                     //Server settings
                     $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
                     $mail->isSMTP();                                            //Send using SMTP
                     $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
                     $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
                     $mail->Username   = 'kanendeyekhady17@gmail.com';                     //SMTP username
                     $mail->Password   = 'S@l@dedefruit8';                               //SMTP password
                     $mail->SMTPSecure = 'ssl';            //Enable implicit TLS encryption
                     $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
                 
                     //Recipients
                     $mail->setFrom($emetteur,$mot);
                     $mail->addAddress($recepteur);     //Add a recipient
                 
                     //Content
                     $mail->isHTML(true);                                  //Set email format to HTML
                     $mail->Subject = $sujet;
                     $mail->Body    = $message;            
                     $mail->send();
                     echo 'Message has been sent';
                 } 
                 
                 catch (Exception $e) {
                     echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
                 }
                 
                }
              }

           ?>            
     </div>
    </div>
</div>
</div>
        

<header id="header" style="height: 600px;">
    <div class="d-flex flex-column">
      <div class="profile">
      
      <nav id="navbar" class="nav-menu navbar" style="height:600px">
      <?php
                    include ("connect_BD.php");
                    $rep=$con->query("select image from image where idClient='$idClient'");
                    while($row=$rep->fetch()){
                     echo '<img  style=" width: 100px;height: 100px;  border-radius:2rem;  margin-bottom:10px; margin-top: 60px; margin-left: 70px;  " src="'.$row['image'].'" >';
                    }
      ?>
        <ul>
          <li><a href="index.php" class="nav-link scrollto active"><i class="bx bx-home"></i> <span>Acceuil</span></a></li>
          <li><a href="#" class="nav-link scrollto"><i class="bi bi-search"></i> <span>Rechercher</span></a></li>
          <li><a href="formCI.php" class="nav-link scrollto" target="_self"><i class="bi bi-pencil-square"></i><span>Creer incident</span></a></li>
          <li><a href="../index.php" class="nav-link scrollto"><i class="bi bi-power"></i> <span>Déconnexion</span></a></li>
        </ul>
      </nav><!-- .nav-menu -->
    </div>
  </header><!-- End Header -->
</body>
    </html>

