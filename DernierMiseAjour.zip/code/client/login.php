<?php

session_start();
             
             try{

              $con = new PDO('mysql:host=localhost;dbname=Gestion_Incidents', 'root', 'dija98');
             }
             catch(Exception $e)
            {
                    die('Erreur : '.$e->getMessage());
            }
             $message="";
            if(!empty($_POST['email']) && !empty($_POST['password']))

            {
              $email=$_REQUEST['email'];
              $password =md5 ($_REQUEST['password']);
 
                 $req="select emailClient, passwordClient,idClient,nomClient from Client where emailClient='$email' and passwordClient='$password'";
                 $res= $con->prepare($req);
                 $res-> execute();
                 $count = $res->rowCount();
                  
                   if($count==1)
                   {
                    while($row=$res->fetch())
                    {
                      $_SESSION['email']  = $row['email'];
                      $_SESSION['idClient']  = $row['idClient'];
                      $_SESSION['nomClient'] =$row['nomClient'];
                      }
                       header('Location: acceuilClient/index.php');
                       exit();
                   }
 
                   else{
                     $message = "Le nom d'utilisateur ou le mot de passe est incorrect.";
                     header('Location: index.php');

                   }
            }
        
?>