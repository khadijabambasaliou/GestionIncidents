<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="style/styleCon.css"/>

    <title>ConnexionPage</title>
</head>
<body>
    <div class="banner">
        <div class="navbar">
            <img src="images/logo.png" alt="logo">
            <ul>
                <li><a href="#" class="nav">Contact</a></li>
                <li><a href="index.php" class="nav">Accueil</a></li>
            </ul>
        </div>
        <div id="login-form" class="login-page">
            <div class="form-box">
                  <div><i class="fas far fa-user-circle icone1 " style="  font-size: 90px; margin-bottom: 20px;   margin-top: 30px; margin-left: 100px;" ></i></div>
                <form action="login.php" id="login" method="post">
                  
                    <input type="email" name="email" class="input" placeholder="email" required>
                    <input type="password" name="password" class="input" placeholder="Mot de passe" required>
                    <input type="checkbox" name="remember" class="check-box"><span>Se souvenir de moi</span>
                    <button type="submit" class="submit-btn" name="submit">se connecter</button>
                </form>
                <a href="#" class="forgetPass">Mot de passe oublié?</a>
            </div>
        </div>
    </div>
</body>
</html>


<?php



?>