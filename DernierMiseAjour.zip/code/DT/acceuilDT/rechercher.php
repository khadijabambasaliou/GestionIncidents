<?php 
session_start();
$servername = "localhost";
$username = "root";
$password = "dija98";
$dbname = "Gestion_Incidents";
 $idUse=$_SESSION['idUser'];
$conn = mysqli_connect($servername, $username, $password, $dbname) or die("Connection failed: " . mysqli_connect_error());

?>

  <!DOCTYPE html>
<html>
	<title> RechercheDT</title>
	<head>
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
<link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
				<link rel="stylesheet" href="DataTables/jquery-ui/jquery-ui.min.css">
				<link rel="stylesheet" href="Navbar/styleNavbar.css">

<script src="DataTables/jquery.min.js"></script>


  <link href="bootstrap3.7/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="bootstrap3.7/docs/assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <link href="bootstrap3.7/dist/dashboard.css" rel="stylesheet">
    <link href="bootstrap3.7/dist/theme.css" rel="stylesheet">

    <script type="text/javascript" src="bootstrap3.7/angular.min.js"></script>

    <script src="bootstrap3.7/docs/assets/js/ie-emulation-modes-warning.js"></script>

  <script src="DataTables/jquery.dataTables.min.js"></script>
    <link href="DataTables/jquery.dataTables.min.css" rel="stylesheet">

<script src="DataTables/datatables.min.js"></script>
    <link href="DataTables/datatables.min.css" rel="stylesheet">

  <script src="DataTables/dataTables.bootstrap.min.js"></script> 
  <link href="DataTables/dataTables.bootstrap.min.css" rel="stylesheet">
 
<script src="DataTables/bootstrap6.min.js"></script> 
  <link href="DataTables/bootstrap6.min.css" rel="stylesheet">

<link rel="stylesheet" href="bootstrap3/bootstrap-datepicker.css" />
  <script src="bootstrap3/bootstrap-datepicker1.js"></script>
      <script src="bootstrap3/bootstrap-datepicker.fr.min.js"></script>

 		 <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
		<script type="text/javascript" language="javascript" >
			$(document).ready(function() {
			
				var dataTable =  $('#employee-grid').DataTable( {
				processing: true,
				serverSide: true,
	 
   				lengthMenu:[ [10, 25, 50, 100,200, -1], [10,25,50,100,200, "Tout"] ],
				ajax: "clientincident-data.php", 
				// json datasource
  dom: 'lBfrtip',
   buttons: [
'copy', 'excel', 'pdf', 'print'   ],
    
				} );
				
				$("#employee-grid_filter").css("display","none");  // hiding global search box
				
				$('.employee-search-input').on( 'keyup click change', function () {   
					var i =$(this).attr('id');  // getting column index
					var v =$(this).val();  // getting search input value
					dataTable.columns(i).search(v).draw();
				} );
		
				 $( ".datepicker" ).datepicker({
				 	dateFormat: "yy-mm-dd",
					showOn: "button",
					showAnim: 'slideDown',
					showButtonPanel: true ,
					autoSize: true,
					buttonImage: "DataTables/calendar.gif",
					buttonImageOnly: true,
					buttonText: "Select date",
					closeText: "Clear"

				});
				$(document).on("click", ".ui-datepicker-close", function(){
					$('.datepicker').val("");
					dataTable.columns(5).search("").draw();
				});
			} );

		</script>
		
		
	</head>
	
	
	<body style="font-family: 'Roboto';">
	
	
	<h4 align="center" style="color:green; font-weight: bold; font-size:25px; "><img src="Navbar/logo.png" height="100" align="center">&nbsp;&nbsp;&nbsp;&nbsp; Bienvenue dans la base de recherche de tous les incidents.</h4>

<div class="container">

<p class="box-register" ><a href="index.php" style="color: #4d9d2a;font-weight:bold;margin-left:20px; font-size :25px;"><i class="bi bi-arrow-left-circle"></i>Retour</a></p>

<h3> Critéres de recherche</h3><br>
		
        <thead>
					<tr>
					
					
			
					
					<td>
					<label >ID</label>
					<input type="text" id="0"  class="employee-search-input form-control"></td>
					
					
					
					<td>  
					 	<label >Intitule Incident :</label>
							<input type="text" id="1"  class="employee-search-input form-control"></td>
					</td>
          <td><label>Status</label>
<select name="nom" id="2" class="employee-search-input form-control">
  <option selected=""></option>
  <option value="encours">encours</option>
  <option value="cree">cree</option>
  <option value="cloture">clôture</option>

        </select> </td>

					 <br>
           <td  valign="middle"><input  readonly="readonly" type="text" id="4" class="employee-search-input datepicker form-control" ></td>

						
					</tr>
				</thead>
				<br><br>

			
							<br><br>
							<table id="employee-grid" class="table table-bordered table-striped">
      <thead>
               <th >IdIunique</th>
              <th >Intitule Incident</th>
              <!--<th >N°Serie </th>-->
              <!--<th >Type</th>-->
              <th >Status</th>
              <!--<th >Date Debut</th>-->
              <th >Ingenieur Affecte</th>
              <!--<th >Ingenieur</th>-->

              <th >Date creation</th>
              <th >categorie</th>
              <th >equipement</th>
              <!--<th >N° Support</th>-->


      </thead>
      
  
   </table>
   
		</div>
		
	</body>
</html>
