<?php
session_start();
 $email=$_SESSION['email'] ;
 $idClient=$_SESSION['idClient'];
 $mot = $_SESSION['nomClient'];
 include ("connect_BD.php");
?>

<html>
<head>
 <!-- Google Fonts -->
 <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="assets/vendor/aos/aos.css" rel="stylesheet">
<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
<link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

<link rel="stylesheet" href="Navbar/styleNavbar.css">


<!-- Template Main CSS File -->
<link href="assets/css/style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">



<style>

td{
    padding:10px;
}

    </style>

</head>
<body>
      <div>
            <div style="margin-left : 250px;  position:absolute;">

                    <table>

                            <tbody>
                            <?php
                                            include ("connect_BD.php");
                                            $id=$_GET['idIncident'];
                                            $req=$con->query("select *  from Incident where idIncident='$id' ");
                            while($row = $req->fetch(PDO::FETCH_ASSOC)) :
                            ?>
                                <tr><td style="font-size:15px; color:#4d9d2a; font-weight: bold;">Intitule de l'incident :</td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['intituleIncident']); ?></td></tr>
                                <tr><td style="font-size:15px; color:#6d6e72; font-weight: bold;">Description : </td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['descriptionIncident']); ?></td></tr>
                                <tr><td style="font-size:15px; color:#6d6e72; font-weight: bold;">Equipement Concerné : </td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['equipementConcerne']); ?></td></tr>
                                <tr><td style="font-size:15px; color:#6d6e72; font-weight: bold;">Date de creation de l'incident :  </td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['dateCreationIncident']); ?></td></tr>
                                <tr><td style="font-size:15px; color:#6d6e72; font-weight: bold;">Niveau de criticité : </td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['niveauCriticite']); ?></td></tr>
                                <tr><td style="font-size:15px; color:#6d6e72; font-weight: bold;">Ingénieur assigné : </td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['ingenieurAffecte']); ?></td></tr>
                                <?php endwhile; ?>
                            </tbody>
                    </table><hr style="height: 3px;">


         <div>
                    <form method="post" action="">
                              <label  style="color:#4d9d2a;font-weight:bold;margin-left:20px; font-size :20px;"><i class="bi bi-chat-dots"></i>Commentaires( 
                                <?php 

                                          $req="select idCommentaire from Commentaire where Commentaire.idIncident='$id'";
                                          $res= $con->prepare($req);
                                          $res-> execute();
                                          $count = $res->rowCount();
                                          echo $count;
                              ?> )</label><br>
<table >

                  <tbody >
                  <?php
                                  include ("connect_BD.php");
                                  $id=$_GET['idIncident'];
                                
                                  $req=$con->query("select * from Commentaire where Commentaire.idIncident='$id'  order by dateCommentaire asc");
                  while($row = $req->fetch(PDO::FETCH_ASSOC)) :
                  ?>
                      <tr ><td style="font-size:15px; color:#6d6e72; font-weight: bold;">
                      <?php 
                      
                                
                                      $identifiantU =$row['idUser'];
                                      $identifiantC = $row['idClient'];
                                      $rp=$con->query("select * from User where idUser='$identifiantU'");
                                      while($lig=$rp->fetch()){
                                        $profil=  $lig['profilUser'];
                                        $pre = $lig['prenomUser'];
                                        $name=$lig['nomUser'];
                                        }
                                    
                                          if($profilUser='Directeur technique' && $identifiantU==1 && $identifiantC==NULL)
                                          {   
                                        
                                        $rep=$con->query("select * from User where idUser=1");
                                        while($ligne=$rep->fetch()){
                                          $prenom=  $ligne['prenomUser'];
                                         $nomU = $ligne['nomUser'];
                                         echo $prenom." "."$nomU"." ( ".$profil." )";  }
                                         
                                          }
                                            else if($identifiantC==$idClient)
                                              {     
                                                  $requete=$con->query("select * from Client where idClient='$idClient'");
                                                  while($ligne=$requete->fetch()){
                                                  $nom= $ligne['nomClient'];
                                                  echo  $nom; 
                                               
                                                }
                                              }
                                            {     
                                                $reque=$con->query("select * from User where idUser='$identifiantU' and profilUser!='Directeur technique'");
                                                while($lign=$reque->fetch()){
                                            
                                                echo  $pre." ".$name." ( ".$profil." )";     
                                              }
                                            } 
                                        
                        ?>    
                       </td>
                       <td></td><td></td><td></td><td></td><td></td><td></td><td><?php echo htmlspecialchars($row['dateCommentaire']); ?></td></tr>
                       <tr><td style="font-size:15px;font-weight: bold;"><?php   echo htmlspecialchars($row['commentaire']); ?></td></tr>
           <?php  endwhile; ?>
                  </tbody>
</table>
                              <textarea class="form-control" name="comment" rows="4" type="text"></textarea><br>
                              <button  type="submit" name="submit" class="btn btn-secondary button " style="margin-left:900px; font-size :20px;"> Send Comment </button>  
                              <p class="box-register" ><a href="index.php" style="color: #4d9d2a;font-weight:bold;margin-left:20px; font-size :20px;"><i class="bi bi-arrow-left-circle"></i>Retour</a></p>
                    </form>

                <?php
                      if(isset($_POST['submit']))
                     { 
                     $idIncident=$_GET['idIncident'];
                     $commentaire=$_POST['comment'];
                     $date = date('Y-m-d H:i:s.u');

                     $req="insert into Commentaire(commentaire,dateCommentaire,idClient,idIncident)values('$commentaire','$date','$idClient','$idIncident')";
                     $res= $con->prepare($req);
                     $res-> execute(); 

                    }
                ?>

                 </div>
             </div>    
      </div>
      <header style="position:fixed;">
            <div class="header-item">
            <img src="Navbar/logo.png" alt="logo" class="logo-head">
                <ul >
                    <li class="profil">
                        <span class="navbar-title-head">
                        <?php
                            $rep=$con->query("select image from image where idClient='$idClient'");
                    while($row=$rep->fetch()){
                     echo '<img  style=" width: 100px;height: 40px;  border-radius:2rem;    " src="'.$row['image'].'" >';
                    }

      ?>
                        </span>
                    </li>
                </ul>
            </div>
        </header>
        <nav class="navbar" style="position:fixed;">
            <ul class="navbar-menu">
                <li class="navbar-items logo">
                    <a href="#" class="navbar-link">
                        <span class="navbar-title">
                        <?php
                             $rep=$con->query("select image from image where idClient='$idClient'");
                             while($row=$rep->fetch()){
                              echo '<img  style=" width: 100px;height: 60px;  border-radius:2rem;    " src="'.$row['image'].'" >';
                             }
                        ?>
                        </span>
                        <i class="fas fa-chevron-right navbar-icon"></i>    
                    </a>
                </li>
                <li class="navbar-items">
                    <a href="index.php" class="navbar-link">
                        <i class="fas fa-home navbar-icon"></i>
                        <span class="navbar-title">Accueil</span>
                    </a>
                </li>
                <li class="navbar-items">
                    <a href="rechercher.php" class="navbar-link">
                        <i class="fas fa-search navbar-icon"></i>
                        <span class="navbar-title">Rechercher</span>
                    </a>
                </li>
                <li class="navbar-items">
                    <a href="formCI.php" class="navbar-link">
                        <i class="fas fa-edit navbar-icon"></i>
                        <span class="navbar-title">Créer incident</span>
                    </a>
                </li> 
             
                <li class="navbar-items">
                    <a href="../index.php" class="navbar-link">
                        <i class="fas fa-sign-out-alt navbar-icon"></i>
                        <span class="navbar-title">Deconnexion</span>
                    </a>
                </li>
            </ul>
        </nav>

</body>
    </html>

