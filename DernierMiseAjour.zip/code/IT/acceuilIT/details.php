<?php
session_start();
$email=$_SESSION['email'] ;
$Nom= $_SESSION['nomUser'];
$Prenom=$_SESSION['prenomUser'];
$idUser=$_SESSION['idUser'];
$idii=$_GET['idIncident'];
 include ("connect_BD.php");
?>

<html>
<head>
<meta charset="utf-8">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

 <!-- Google Fonts -->
 <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="assets/vendor/aos/aos.css" rel="stylesheet">
<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
<link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<link rel="stylesheet" href="Navbar/styleNavbar.css">
    

<!-- Template Main CSS File -->
<link href="assets/css/style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

 

<style>
      

td{
    padding:10px;
}
  </style>

</head>
<body>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Clôturer l'incident intitulé :

                <table>

                <tbody>
                <?php
                                $req=$con->query("select *  from Incident where idIncident='$idii' ");
                while($row = $req->fetch(PDO::FETCH_ASSOC)) :
                ?>
                    <tr><td></td><td style="font-size:20px; color:#4d9d2a; font-weight: bold; font-weight: bold;"><?php echo htmlspecialchars($row['intituleIncident']); ?></td></tr>
                    
                    <?php endwhile; ?>
                </tbody>
                </table>
        
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form  method="post">
                  <label style="margin-left:10px;font-size:15px; color:#6d6e72; font-weight: bold; ">Êtes-vous sûr de vouloir clôturer l'incident ?</label>
                  </div>
      <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" style="margin-right:270px; ">Annuler</button>
      <button type="submit" class="btn btn-primary" name="clo" style=" background-color:#4d9d2a;;"> Clôturer</button> </form>
        <?php 
       
        
                $date = date('Y-m-d H:i:s.u');

             if(isset($_POST['clo']))
             {  
                  
                      $req="update Incident set statusIncident='cloture', dateClotureIncident='$date' where idIncident='$idii'" ;
                      $res= $con->prepare($req);
                      $res-> execute();  
                     
                        header('Location: index.php');
                      
             }
             
            
        ?>
      </div>
    </div>
  </div>
</div>

      <div>
            <div style="margin-left : 200px;  position:absolute; margin-top:100px;">

                    <table>

                            <tbody>
                            <?php
                                            include ("connect_BD.php");
                                            $req=$con->query("select *  from Incident where idIncident='$idii' ");
                            while($row = $req->fetch(PDO::FETCH_ASSOC)) :
                            ?>
                                <tr><td style="font-size:15px; color:#4d9d2a; font-weight: bold;">Intitule de l'incident :</td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['intituleIncident']); ?></td></tr>
                                <tr><td style="font-size:15px; color:#6d6e72; font-weight: bold;">Description : </td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['descriptionIncident']); ?></td></tr>
                                <tr><td style="font-size:15px; color:#6d6e72; font-weight: bold;">Equipement Concerné : </td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['equipementConcerne']); ?></td></tr>
                                <tr><td style="font-size:15px; color:#6d6e72; font-weight: bold;">Date de creation de l'incident :  </td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['dateCreationIncident']); ?></td></tr>
                                <tr><td style="font-size:15px; color:#6d6e72; font-weight: bold;">Niveau de criticité : </td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['niveauCriticite']); ?></td></tr>
                                <?php endwhile; ?>
                            </tbody>
                    </table><hr style="height: 3px;"> 
                    <?PHP
                    $status="";
                   $iD="";
                   $statu="";
                    $requete2="select * from Incident where idIncident='$idii'and idUser='$idUser'";
                    $res2= $con->prepare($requete2);
                    $res2-> execute();
                    while($row=$res2->fetch()){
                    $statu=$row['statusIncident'];
                                         }

                                         $requete="select * from Reaffectation where idIncident='$idii'";
                                         $res= $con->prepare($requete);
                                         $res-> execute();
                                         while($row=$res->fetch()){
                                         $iD = $row['idUser'];
                                       
                                                             } 
                             
                             if($iD==NULL && $statu!="cloture")
                             {
                                 $status="enabled"; 
                             }
                             else if($iD==$idUser && $statu!="cloture")
                             {
                                $status="enabled"; 
                             }
                             else {
                              
                                $status="disabled"; 
                             }
                               
  

         
                             
                
                
                    
?>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal" style="margin-left:870px; background-color: #4d9d2a; height: 35px; width: 150px;border-radius:0.9rem;"  <?php echo  $status ?> > Clôturer Incident</button>
                    <hr style="height: 3px;">
         <div>
                    <form method="post" action="">
                              <label  style="color:#4d9d2a;font-weight:bold;margin-left:20px; font-size :20px;"><i class="bi bi-chat-dots"></i>Commentaires( 
                                <?php 

                                          $req="select idCommentaire from Commentaire where Commentaire.idIncident='$idii'";
                                          $res= $con->prepare($req);
                                          $res-> execute();
                                          $count = $res->rowCount();
                                          echo $count;
                              ?> )</label><br>
<table >

                  <tbody >
                  <?php
                                  include ("connect_BD.php");
                                
                                  $req=$con->query("select * from Commentaire where Commentaire.idIncident='$idii'  order by dateCommentaire asc");
                  while($row = $req->fetch(PDO::FETCH_ASSOC)) :
                  ?>
                      <tr ><td style="font-size:15px; color:#6d6e72; font-weight: bold;">
                      <?php 
                      
                                
                                      $identifiantU =$row['idUser'];
                                      $identifiantC = $row['idClient'];
                                      $pre="";

                                      $rp=$con->query("select * from User where idUser='$identifiantU'");
                                        while($lig=$rp->fetch()){
                                          $profil=  $lig['profilUser'];
                                          $pre = $lig['prenomUser'];
                                          }
                                   
                                          if( $identifiantU==1 && $profil== 'Directeur technique')
                                          {   
                                        
                                        $rep=$con->query("select * from User where idUser=1");
                                        while($ligne=$rep->fetch()){
                                          $prenom=  $ligne['prenomUser'];
                                         $nomU = $ligne['nomUser'];
                                         echo $prenom." "."$nomU"." ( ".$profil." )";  }
                                         
                                          }

                                         else if(   $Prenom == $pre)
                                          {   
                                        
                                        $re=$con->query("select * from User where idUser='$identifiantU'");
                                        while($li=$re->fetch()){
                                         echo " Moi ";  }
                                         
                                          }
                                          else if($identifiantU!=$idUser){
                                            $repp=$con->query("select * from User where idUser='$identifiantU'");
                                            while($ligne=$repp->fetch()){
                                              $prenom=  $ligne['prenomUser'];
                                             $nomU = $ligne['nomUser'];
                                             echo $prenom." "."$nomU"." ( ".$profil." )";  }

                                          }

                                          
                                              {     
                                                  $requete=$con->query("select * from Client where idClient='$identifiantC'");
                                                  while($ligne=$requete->fetch()){
                                                  $nomm= $ligne['nomClient'];
                                                  echo  $nomm;     
                                                }
                                              }            
                        ?>    
                       </td>
                       <td></td><td></td><td></td><td></td><td></td><td></td><td><?php echo htmlspecialchars($row['dateCommentaire']); ?></td></tr>
                       <tr><td style="font-size:15px;font-weight: bold;"><?php   echo htmlspecialchars($row['commentaire']); ?></td></tr>
           <?php  endwhile; ?>
                  </tbody>
</table>
                              <textarea class="form-control" name="comment" rows="4" type="text"></textarea><br>
                              <button  type="submit" name="submit" class="btn btn-secondary button " style="margin-left:900px; font-size :20px;"> Send Comment </button>  
                              <p class="box-register" ><a href="index.php" style="color: #4d9d2a;font-weight:bold;margin-left:20px; font-size :20px;"><i class="bi bi-arrow-left-circle"></i>Retour</a></p>
                    </form>

                <?php
                      if(isset($_POST['submit']))
                     { 
                     $idIncident=$_GET['idIncident'];
                     $commentaire=$_POST['comment'];
                     $date = date('Y-m-d H:i:s.u');

                     $req="insert into Commentaire(commentaire,dateCommentaire,idUser,idIncident)values('$commentaire','$date','$idUser','$idIncident')";
                     $res= $con->prepare($req);
                     $res-> execute(); 
                            
                    }
                ?>

                 </div>
             </div>    
      </div>

      
      <header style="position:fixed;">
            <div class="header-item">
            <img src="Navbar/logo.png" alt="logo" class="logo-head">
                <ul >
                    <li class="profil">
                            <i class="far fa-user navbar-icon-head"></i>
                        <span class="navbar-title-head">
                        <?php
                            include ("connect_BD.php");
                            $rep=$con->query("select  nomUser,prenomUser from User where idUser='$idUser'");
                            while($row=$rep->fetch()){
                                echo $row['prenomUser']." ".$row['nomUser'];
                            }
                        ?>
                        </span>
                    </li>
                </ul>
            </div>
        </header>
        <nav class="navbar" style="position:fixed;">
            <ul class="navbar-menu">
                <li class="navbar-items logo">
                    <a href="#" class="navbar-link">
                        <span class="navbar-title">
                        <?php
                            include ("connect_BD.php");
                            $rep=$con->query("select  nomUser,prenomUser from User where idUser='$idUser'");
                            while($row=$rep->fetch()){
                                echo $row['prenomUser']." ".$row['nomUser'];
                            }
                        ?>
                        </span>
                        <i class="fas fa-chevron-right navbar-icon"></i>    
                    </a>
                </li>
                <li class="navbar-items">
                    <a href="index.php" class="navbar-link">
                        <i class="fas fa-home navbar-icon"></i>
                        <span class="navbar-title">Accueil</span>
                    </a>
                </li>
                <li class="navbar-items">
                    <a href="rechercher.php" class="navbar-link">
                        <i class="fas fa-search navbar-icon"></i>
                        <span class="navbar-title">Rechercher</span>
                    </a>
                </li>
                <!-- <li class="navbar-items">
                    <a href="#" class="navbar-link">
                        <i class="fas fa-edit navbar-icon"></i>
                        <span class="navbar-title">Créer incident</span>
                    </a>
                </li>-->
                <li class="navbar-items">
                    <a href="incidentEncours.php" class="navbar-link">
                        <i class="fas fa-ticket-alt navbar-icon"></i>
                        <span class="navbar-title">incident encours</span>
                    </a>
                </li> 
             
                <li class="navbar-items">
                    <a href="../index.php" class="navbar-link">
                        <i class="fas fa-sign-out-alt navbar-icon"></i>
                        <span class="navbar-title">Deconnexion</span>
                    </a>
                </li>
            </ul>
        </nav>

                   

  
 
</body>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    </html>

