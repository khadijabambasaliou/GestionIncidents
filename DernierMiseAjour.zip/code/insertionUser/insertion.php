<html>
    <head></head>

    <body>

    <form  action="insertionAction.php" method="post" name="form">
    <input type="text" name="name"  class="form-control" id="name" aria-describedby="nameHelp" placeholder="Enter name" required><br>
    <input type="text" name="prenom"  class="form-control" id="prenom" aria-describedby="prenomHelp" placeholder="Enter prenom" required><br>
    <input type="text" name="email"  class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter email" required><br>
                <input type="text" name="password" id="password"  class="form-control" aria-describedby="emailHelp" placeholder="Enter Password" required><br>
                <input type="text" name="departement"  class="form-control"  placeholder="departement" required><br>
                <input type="text" name="profil"  class="form-control"  placeholder="le profil " required><br>
                <input type="int" name="status"  class="form-control"  placeholder="le status " required><br>
                <input type="submit" value="enregistrer " name="submit" class="btn btn-primary submit " ><br><br>
    </form>

    </body>

</html>

