<?php
                              $con = new PDO('mysql:host=localhost;dbname=Gestion_Incidents', 'root', 'dija98');
?>