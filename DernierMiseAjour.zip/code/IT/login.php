<?php

session_start();
             
             try{

              $con = new PDO('mysql:host=localhost;dbname=Gestion_Incidents', 'root', 'dija98');
             }
             catch(Exception $e)
            {
                    die('Erreur : '.$e->getMessage());
            }
             $message="";
            if(!empty($_POST['email']) && !empty($_POST['password']))

            {
              $email=$_REQUEST['email'];
              $password =md5 ($_REQUEST['password']);
 
                 $req="select * from User where emailUser='$email' and passwordUser='$password'";
                 $res= $con->prepare($req);
                 $res-> execute();
                 $count = $res->rowCount();
                  
                   if($count==1)
                   {
                    while($row=$res->fetch())
                    {
                      $_SESSION['email']  = $row['emailUser'];
                      $_SESSION['idUser']  = $row['idUser'];
                      $_SESSION['prenomUser'] =$row['prenomUser'];
                      $_SESSION['nomUser'] =$row['nomUser'];

                      }
                       header('Location: acceuilIT/index.php');
                   }
 
                   else{
                     $message = "Le nom d'utilisateur ou le mot de passe est incorrect.";
                     header('Location: index.php');

                   }
            }
        
?>