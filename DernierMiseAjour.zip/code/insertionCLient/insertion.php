<html>
    <head></head>

    <body>

    <form  action="insertionAction.php" method="post" name="form">
                <input type="text" name="email"  class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter email" required><br>
                <input type="text" name="password" id="password"  class="form-control" aria-describedby="emailHelp" placeholder="Enter Password" required><br>
                <input type="text" name="nom"  class="form-control"  placeholder="Nom de l'entreprise" required><br>
                <input type="int" name="status"  class="form-control"  placeholder="le status " required><br>
                <input type="submit" value="enregistrer " name="submit" class="btn btn-primary submit " ><br><br>
    </form>

    </body>

</html>