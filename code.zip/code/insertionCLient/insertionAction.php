<?php

$con = new PDO('mysql:host=localhost;dbname=Gestion_Incidents', 'root', 'dija98');
if(!empty($_POST['email']) && !empty($_POST['password']))

            {

                $email=$_REQUEST['email'];
              $password =md5($_REQUEST['password']);
              $nom=$_REQUEST['nom'];
              $status=$_REQUEST['status'];

              $req="insert into Client(nomClient,emailClient,passwordClient,statusClient)values ('$nom','$email','$password','$status')";
              $res= $con->prepare($req);
              $res-> execute();
              if($res)
              {
                  echo'insertion reussi';
              }
              else
              {
                  echo 'insertion non reussi';
              }
            }



?>