<?php
session_start();
 $email=$_SESSION['email'] ;
 $idClient=$_SESSION['idClient'];
 include ("connect_BD.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Client</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/sesam.png" rel="icon">
  <link href="assets/img/sesam.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="styles.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
				<link rel="stylesheet" href="Navbar/styleNavbar.css">



  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">


</head>

<body>
  <div style="margin-left : 270px; margin-top :160px; position:absolute;">
  <?php
           $req=$con->query("select * from Incident  where idClient='$idClient' order by  dateCreationIncident desc");
         
          $chaine="
            <table border='2px' width='150%'><tr><th bgcolor='#4D9D2A'>ID incident</th><th bgcolor='#4D9D2A'>Intitulé de l'incident</th><th bgcolor='#4D9D2A'>Date de creation</th><th bgcolor='#4D9D2A'>Status</th><th bgcolor='#4D9D2A'>Ingénieur Assigné</th><th bgcolor='#4D9D2A'>Action</th></tr>";
            while($ligne=$req->fetch()){
               $chaine=$chaine."<tr>
               <td>".$ligne['idUnique']."</td>
               <td>".$ligne['intituleIncident']."</td>
               <td>".$ligne['dateCreationIncident']."</td>
               <td>".$ligne['statusIncident']."</td>
               <td> ".$ligne['ingenieurAffecte']."</td>
               <td><a href='details.php?idIncident=".$ligne['idIncident']."' target='_self'>Details</a></td>
               </tr>";

            }
          $chaine=$chaine."</table>";
          echo $chaine;
          ?>
          
  </div>

 

    <div id="VI" style="margin-top :100px; margin-left:500px;">
          <p>Historique de mes incidents</p>           
    </div>
</div>


                 
                                 
            

               
<header>
            <div class="header-item">
            <img src="Navbar/logo.png" alt="logo" class="logo-head">
                <ul >
                    <li class="profil">
                        <span class="navbar-title-head">
                        <?php
                            $rep=$con->query("select image from image where idClient='$idClient'");
                    while($row=$rep->fetch()){
                     echo '<img  style=" width: 100px;height: 40px;  border-radius:2rem;    " src="'.$row['image'].'" >';
                    }

      ?>
                        </span>
                    </li>
                </ul>
            </div>
        </header>
        <nav class="navbar" style="position:fixed;">
            <ul class="navbar-menu">
                <li class="navbar-items logo">
                    <a href="#" class="navbar-link">
                        <span class="navbar-title">
                        <?php
                             $rep=$con->query("select image from image where idClient='$idClient'");
                             while($row=$rep->fetch()){
                              echo '<img  style=" width: 100px;height: 60px;  border-radius:2rem;    " src="'.$row['image'].'" >';
                             }
                        ?>
                        </span>
                        <i class="fas fa-chevron-right navbar-icon"></i>    
                    </a>
                </li>
                <li class="navbar-items">
                    <a href="#" class="navbar-link">
                        <i class="fas fa-home navbar-icon"></i>
                        <span class="navbar-title">Accueil</span>
                    </a>
                </li>
                <li class="navbar-items">
                    <a href="rechercher.php" class="navbar-link">
                        <i class="fas fa-search navbar-icon"></i>
                        <span class="navbar-title">Rechercher</span>
                    </a>
                </li>
                <li class="navbar-items">
                    <a href="formCI.php" class="navbar-link">
                        <i class="fas fa-edit navbar-icon"></i>
                        <span class="navbar-title">Créer incident</span>
                    </a>
                </li> 
             
                <li class="navbar-items">
                    <a href="../index.php" class="navbar-link">
                        <i class="fas fa-sign-out-alt navbar-icon"></i>
                        <span class="navbar-title">Deconnexion</span>
                    </a>
                </li>
            </ul>
        </nav>

                        
            


  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/typed.js/typed.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>