<?php
session_start();
 $email=$_SESSION['email'] ;
 $idUser=$_SESSION['idUser'];
?>


<html>
<head>
 <!-- Google Fonts -->
 <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="assets/vendor/aos/aos.css" rel="stylesheet">
<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
<link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">



<!-- Template Main CSS File -->
<link href="assets/css/style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">



<style>


.verte{
        height: 15px;
        width: 100%;
        background-color: #4d9d2a;
        opacity: 0.8;
      }
      #formback{
        margin-left: 300px;
        width: 1050px; 
        background-color: FFFFFF;
        height:600px;  
        position: absolute;
      }
      .navbar{
width: 100%;
height: 8%;
margin: auto;
display: flex;
align-items: center;
background-color: #fcfcfc;
}


    </style>

</head>
<body>
<div class="verte"></div>
   
<div class="container" id="formback">
        <div style="  margin-left: 770px;   font-size: 25px; margin-top:9px; color:#6d6e72; font-weight: bold;">
                            <i class="bi bi-person-fill" ></i>
                  <?php
                                include ("connect_BD.php");
                                $rep=$con->query("select  nomUser,prenomUser from User where idUser='$idUser'");
                                while($row=$rep->fetch()){
                                echo $row['prenomUser']." ".$row['nomUser'];
                                }

                  ?>
        </div>
     
       <hr style="height: 5px;">

      <div>
        <table>

              <tbody>
              <?php
                              include ("connect_BD.php");
                              $req=$con->query("select *  from Incident, Client where Incident.idClient = Client.idClient and ingenieurAffecte='Aucun'order by dateCreationIncident desc ");
              while($row = $req->fetch(PDO::FETCH_ASSOC)) :
              ?>
                  <tr><td style="font-size:30px; color:#4d9d2a; font-weight: bold; padding: 30px;" >Intitule de l'incident :</td><td style="font-size:30px;font-weight: bold;"><?php echo htmlspecialchars($row['intituleIncident']); ?></td></tr>
                  <tr><td style="font-size:20px; color:#6d6e72; font-weight: bold;">   Client </td><td style="font-size:20px;font-weight: bold;"><?php echo htmlspecialchars($row['nomClient']); ?></td></tr>
                  <tr><td style="font-size:20px; color:#6d6e72; font-weight: bold;">Date de creation : </td><td style="font-size:20px;font-weight: bold;"><?php echo htmlspecialchars($row['dateCreationIncident']); ?></td></tr>
                  <tr><td></td><td style="font-size:20px; color:#6d6e72; font-weight: bold;"><?php echo " <a href='affectation.php?idIncident=".$row['idIncident']."' target='_self'>VoirPlus</a>"?><i class="bi bi-eye"  ></i></td></td></tr>
                  <tr><td><hr style="height: 5px;"></td><td><hr style="height: 5px;"></td></tr>
                  
                  <?php endwhile; ?>  
              </tbody>
        </table>
      </div>
</div>
        

<header id="header">
    <div class="d-flex flex-column">
      <div class="profile">
    
      <nav id="navbar" class="nav-menu navbar" style="height: 700px;">
      
        <ul>
          <li><a href="index.php" class="nav-link scrollto active"><i class="bx bx-home"></i> <span>Acceuil</span></a></li><br>
          <li><a href="#" class="nav-link scrollto"><i class="bi bi-search"></i> <span>Rechercher</span></a></li><br>
          <li><a href="formCI.php" class="nav-link scrollto" target="_self"><i class="bi bi-pencil-square"></i><span>Incident à affecter</span></a></li><br>
          <li><a href="../../index.php" class="nav-link scrollto"><i class="bi bi-bar-chart-line"></i> <span>Statistiques</span></a></li><br>
          <li><a href="../index.php" class="nav-link scrollto"><i class="bi bi-power"></i> <span>Déconnexion</span></a></li>
        </ul>
      </nav><!-- .nav-menu -->
    </div>
  </header><!-- End Header -->
</body>
    </html>

