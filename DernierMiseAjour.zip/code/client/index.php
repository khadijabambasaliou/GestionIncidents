<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/styleIndex.css"/>
    <title>HomePage</title>
</head>
<body>
    <div class="banner">
        <div class="navbar">
            <img src="images/logo.png" alt="logo">
            <ul><li><a href="#" class="nav">Contact</a></li></ul>
        </div>
        <div class="content">
            <h1>Gestion des incidents</h1>
            <p>La plateforme qui gère vos incidents en toute sécurité</p>
            <button type="button"><span></span><a href="connexion.php" class="connect">LOGIN</a> </button>
        </div>
    </div>
</body>
</html>
