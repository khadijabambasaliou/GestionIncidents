<?php
session_start();
 $email=$_SESSION['email'] ;
 $idUser=$_SESSION['idUser'];
?>


<html>
<head>
 <!-- Google Fonts -->
 <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="assets/vendor/aos/aos.css" rel="stylesheet">
<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
<link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">


<link rel="stylesheet" href="Navbar/styleNavbar.css">

<!-- Template Main CSS File -->
<link href="assets/css/style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">



<style>


      #formback{
        margin-top:100px;
        margin-left: 250px;
        width: 1050px; 
        background-color: FFFFFF;
        height:600px;  
        position: absolute;
      }
    
#affecter{
        color:FFFFFF;
        background-color: #4d9d2a;
        width:120px;
        border-radius:2rem;
        font-weight: bold;
        margin-left: 900px;
      }


    </style>

</head>
<body style="font-family: 'Roboto';">
   
<div class="container" id="formback">
        
<hr style="height: 5px;">
        <div  style=" position:relative; margin-left:10px;">
        <table>
              <tbody>
                <?php
                                include ("connect_BD.php");
                                $id=$_GET['idIncident'];
                                $req=$con->query("select *  from Incident,Client where idIncident='$id' and Incident.idClient = Client.idClient ");
                                while($row = $req->fetch(PDO::FETCH_ASSOC)) :
                ?>
                               <tr><td style="font-size:15px; color:#4d9d2a; font-weight: bold;">Intitule de l'incident :</td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['intituleIncident']); ?></td></tr>
                               <tr><td></td><td></td><td style="font-size:15px; color:#4d9d2a; font-weight: bold;">Nom du client : </td><td style="font-size:25px;font-weight: bold;"><?php echo htmlspecialchars($row['nomClient']); ?></td></tr>
                                <tr><td style="font-size:15px; color:#6d6e72; font-weight: bold;">Description : </td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['descriptionIncident']); ?></td></tr>
                                <tr><td style="font-size:15px; color:#6d6e72; font-weight: bold;">Equipement Concerné : </td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['equipementConcerne']); ?></td></tr>
                                <tr><td style="font-size:15px; color:#6d6e72; font-weight: bold;">Catégorie : </td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['categorieIncident']); ?></td></tr>
                                <tr><td style="font-size:15px; color:#6d6e72; font-weight: bold;">Niveau de criticité : </td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['niveauCriticite']); ?></td></tr>
                                <tr><td></td><td style="font-size:15px; color:#4d9d2a; font-weight: bold;">Date de creation de l'incident :  </td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['dateCreationIncident']); ?></td></tr>
                                <tr><td style="font-size:15px; color:#4d9d2a; font-weight: bold;">Ingénieur assigné : </td><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['ingenieurAffecte']); 
                                          include ("connect_BD.php");
                                          $rep=$con->query("select  * from Reaffectation,Incident where Reaffectation.idIncident='$id' and Incident.idIncident='$id'");
                                          while($row=$rep->fetch()){
                                          $ing = $row['ingenieurReaffecte'];
                                          echo " &nbsp;&nbsp; , ".$ing." (R) ";
                                          }  ?></td></tr>
                                  
                    <?php endwhile; ?>  
                </tbody>
        </table>  
        </div> 
                   
                                        <?php

                                include ("connect_BD.php");                     
                                if(!empty($_POST['reaffectation'])) 
                                {   

                                    $reaffectation=$_POST['reaffectation'];
                                    $id=$_GET['idIncident'];
                                    $requ=$con->query("select * from User where prenomUser='$reaffectation'");
                                    while($row=$requ->fetch()){
                                        $idi=$row['idUser'];
                                    }
                                    $req="insert into Reaffectation (ingenieurReaffecte,idIncident,idUser)values('$reaffectation','$id','$idi')";
                                    $res= $con->prepare($req);
                                    $res-> execute();
                                    header('Location: index.php');
                                    
                                }
                                ?>
             
                                  <br><br>
                <div   id="form">  
                <?php
                                            include ("connect_BD.php");
                                            $id=$_GET['idIncident'];
                                            $req=$con->query("select *  from Incident  where Incident.idIncident='$id' ");
                            while($row = $req->fetch(PDO::FETCH_ASSOC)) :
                            ?>
                <form method="post" >
                <label style="margin-left:10px;  font-weight: bold;">Réaffecter à :</label>
                    <select class="form-select" aria-label="Default select example" name="reaffectation" type="text" style="width: 200px; margin-left:200px;  border-color: #4d9d2a; border-width:2px; border-radius: 0.5rem;">
                    <option selected disabled >  </option>
                    <option   disabled  >Réaffecter  à</option>
                      <option value="Birane">Birane</option>
                      <option value="Khadim">khadim </option>
                      <option value="AWA">AWA</option>
                      <option value="Bamba">Bamba</option>
                      <option value="Khadija">Khadija</option>
                      <option value="Mame Diarra">Mame Diarra</option>
                </select><br>                     
                <button  type="submit" class="btn btn-secondary button " id="affecter" > Réaffecter </button>  <hr><hr>
                </form>  <?php  endwhile; ?>

                <div >
                <form method="post" action="">
                              <label  style="color:#4d9d2a;font-weight:bold;margin-left:20px; font-size :20px;"><i class="bi bi-chat-dots"></i>Commentaires( 
                                <?php 

                                          $req="select idCommentaire from Commentaire where Commentaire.idIncident='$id'";
                                          $res= $con->prepare($req);
                                          $res-> execute();
                                          $count = $res->rowCount();
                                          echo $count;
                              ?> )</label><br><br>
<table >

                  <tbody >
                  <?php
                                  include ("connect_BD.php");
                                  $id=$_GET['idIncident'];
                                
                                  $req=$con->query("select * from Commentaire where Commentaire.idIncident='$id'  order by dateCommentaire asc");
                  while($row = $req->fetch(PDO::FETCH_ASSOC)) :
                  ?>
                      <tr ><td style="font-size:15px; color:#6d6e72; font-weight: bold;">
                      <?php 
                      
                                
                                      $identifiantU =$row['idUser'];
                                      $identifiantC = $row['idClient'];
                                      $rp=$con->query("select * from User where idUser='$identifiantU'");
                                      while($lig=$rp->fetch()){
                                        $profil=  $lig['profilUser'];
                                        
                                        }
                                     
                                          if($identifiantU==1 && $profil== 'Directeur technique')
                                          {   
                                        
                                        $rep=$con->query("select * from User where idUser=1");
                                        while($ligne=$rep->fetch()){
                                         
                                         echo " Moi ";  }
                                         
                                          }
                                            else 
                                            {   
                                        
                                              $re=$con->query("select * from User where idUser='$identifiantU'");
                                              while($li=$re->fetch()){
                                               echo $li['prenomUser']." ".$li['nomUser']." ( ".$li['profilUser']." ) ";  }
                                              }
                                            
                                              {     
                                                  $requete=$con->query("select * from Client where idClient='$identifiantC'");
                                                  while($ligne=$requete->fetch()){
                                                  $nom= $ligne['nomClient'];
                                                  echo  $nom;    
                                                }
                                              }
                              
                        ?>    </td>
                        <td></td><td></td><td></td><td></td><td></td><td></td><td><?php echo htmlspecialchars($row['dateCommentaire']); ?></td></tr>
                       <tr><td style="font-size:15px;font-weight: bold;"><?php echo htmlspecialchars($row['commentaire']); ?></td></tr>
                      
                      <?php  endwhile; ?>
                  </tbody>
</table>
                           <textarea class="form-control" name="comment" rows="4" type="text" ></textarea><br>
                              <button  type="submit" name="submit" class="btn btn-secondary button " style="margin-left:800px; font-size :15px;"> Send Comment </button>  
                              <p class="box-register" ><a href="index.php" style="color: #4d9d2a;font-weight:bold;margin-left:20px; font-size :20px;"><i class="bi bi-arrow-left-circle"></i>Retour</a></p>
                    </form>
                      <?php
                      if(isset($_POST['submit']))
                     {                  
                      
                     $idIncident=$_GET['idIncident'];
                     $commentaire=$_POST['comment'];
                     $date = date('Y-m-d H:i:s.u');

                     $req="insert into Commentaire(commentaire,dateCommentaire,idUser,idIncident)values('$commentaire','$date','$idUser','$idIncident')";
                     $res= $con->prepare($req);
                     $res-> execute(); 

                    }
                ?>
              </div>
            </div>            
</div>
        

<header style="position:fixed;">
            <div class="header-item">
            <img src="Navbar/logo.png" alt="logo" class="logo-head">
                <ul >
                    <li class="profil">
                            <i class="far fa-user navbar-icon-head"></i>
                        <span class="navbar-title-head">
                        <?php
                            include ("connect_BD.php");
                            $rep=$con->query("select  nomUser,prenomUser from User where idUser='$idUser'");
                            while($row=$rep->fetch()){
                                echo $row['prenomUser']." ".$row['nomUser'];
                            }
                        ?>
                        </span>
                    </li>
                </ul>
            </div>
        </header>
        <nav class="navbar" style="position:fixed;">
            <ul class="navbar-menu">
                <li class="navbar-items logo">
                    <a href="#" class="navbar-link">
                        <span class="navbar-title">
                        <?php
                            include ("connect_BD.php");
                            $rep=$con->query("select  nomUser,prenomUser from User where idUser='$idUser'");
                            while($row=$rep->fetch()){
                                echo $row['prenomUser']." ".$row['nomUser'];
                            }
                        ?>
                        </span>
                        <i class="fas fa-chevron-right navbar-icon"></i>    
                    </a>
                </li>
                <li class="navbar-items">
                    <a href="index.php" class="navbar-link">
                        <i class="fas fa-home navbar-icon"></i>
                        <span class="navbar-title">Accueil</span>
                    </a>
                </li>
                <li class="navbar-items">
                    <a href="rechercher.php" class="navbar-link">
                        <i class="fas fa-search navbar-icon"></i>
                        <span class="navbar-title">Rechercher</span>
                    </a>
                </li>
                <!-- <li class="navbar-items">
                    <a href="#" class="navbar-link">
                        <i class="fas fa-edit navbar-icon"></i>
                        <span class="navbar-title">Créer incident</span>
                    </a>
                </li>-->
                <li class="navbar-items">
                    <a href="formCI.php" class="navbar-link">
                        <i class="fas fa-ticket-alt navbar-icon"></i>
                        <span class="navbar-title">incident à affecter</span>
                    </a>
                </li> 
                <li class="navbar-items">
                    <a href="#" class="navbar-link">
                        <i class="fas fa-chart-line navbar-icon"></i>
                        <span class="navbar-title">Statistiques</span>
                    </a>
                </li>
                <li class="navbar-items">
                    <a href="../index.php" class="navbar-link">
                        <i class="fas fa-sign-out-alt navbar-icon"></i>
                        <span class="navbar-title">Deconnexion</span>
                    </a>
                </li>
            </ul>
        </nav>
      
</body>
    </html>

