<?php

$con = new PDO('mysql:host=localhost;dbname=Gestion_Incidents', 'root', 'dija98');
if(!empty($_POST['email']) && !empty($_POST['password']) )

            {

               $name = $_POST['name'];
               $prenom = $_POST['prenom'];
              $email=$_POST['email'];
              $password =md5($_POST['password']);
              $departement=$_POST['departement'];
              $profil=$_POST['profil'];
              $status=$_POST['status'];

              $req="insert into User(nomUser,prenomUser,emailUser,passwordUser,departementUser,profilUser,statusUser)values
               ('$name','$prenom','$email','$password','$departement','$profil','$status')";
              $res= $con->prepare($req);
              $res-> execute();
              if($res)
              {
                  echo'insertion reussi';
              }
              else
              {
                  echo 'insertion non reussi';
              }
            }

?>