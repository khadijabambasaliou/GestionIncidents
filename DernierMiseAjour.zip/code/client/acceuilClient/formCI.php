<?php
session_start();
 $email=$_SESSION['email'] ;
 $idClient=$_SESSION['idClient'];
 $mot = $_SESSION['nomClient'];
 
 include ("connect_BD.php");                     

 use PHPMailer\PHPMailer\PHPMailer;
 use PHPMailer\PHPMailer\SMTP;
 use PHPMailer\PHPMailer\Exception;
 
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

?>


<html>
<head>
 <!-- Google Fonts -->
 <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="assets/vendor/aos/aos.css" rel="stylesheet">
<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
<link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

<link rel="stylesheet" href="Navbar/styleNavbar.css">


<!-- Template Main CSS File -->
<link href="assets/css/style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">



<style>


      #formCI
      {
        margin-left: 20px;
        margin-top:10px;
        width: 1000px; 
        background-color: #F1F6F0 ;
        height: 535px;  
        position: absolute;
        border-radius: 1.1rem;
      }
      #formback{
        margin-top:80px;
        margin-left: 230px;
        width: 1060px; 
        background-color: #9DAA9A;
        height:550px;  
        position: absolute;
        border-radius: 1.1rem;

      }
 

    </style>
    <script>
         function isEmpty(){
             var str = document.forms['myForm'].intituleIncident.value;
             var desc = document.forms['myForm'].descriptionIncident.value;
             var equip = document.forms['myForm'].equipementConcerne.value;
             var cate = document.forms['myForm'].categorieIncident.value;
             var niv = document.forms['myForm'].niveauCriticite.value;

             if( !str.replace(/\s+/, '').length || !desc.replace(/\s+/, '').length) {
                  alert( "les champs  Ne doivent pas être vide!" );
                  return false;
             }
         }
      </script>

</head>
<body>
<div class="modal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p>Modal body text goes here.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>

<?php
if(isset($_POST['valide']))
{
                      if(isset($_POST['intituleIncident']) && isset($_POST['equipementConcerne']) && isset($_POST['categorieIncident']) && isset($_POST['niveauCriticite']) && isset($_POST['descriptionIncident'])) 
                      {    
                  $incident=$_POST['intituleIncident'];
                  $description =$_POST['descriptionIncident'];
                  $categorie =$_POST['categorieIncident'];
                 
                  $criticite=$_POST['niveauCriticite'];
                  $equipement=$_POST['equipementConcerne'];
                  $status="cree";
                  $ingenieur="Aucun";
                  $date = date('Y-m-d H:i:s.u');

                  
                  $idUnique=$_POST['idUnique'];

                  $dateCloture=date('Y-m-d H:i:s.u');
                  $idClient=$_SESSION['idClient'];

                  switch($_POST['niveauCriticite'])
                  {
                      case 1 :
                                $criticite ="Mineur";break;
                      case 2: 
                                $criticite ="Majeur";break;
                       case 3: 
                                $criticite="Critique";break;
                    default:
                            $criticite ="Autre";
                  }
            $req="insert into Incident(idClient,intituleIncident,categorieIncident,descriptionIncident,dateCreationIncident,statusIncident,equipementConcerne,niveauCriticite,ingenieurAffecte,idUnique,dateClotureIncident)
            values('$idClient','$incident','$categorie','$description','$date','$status','$equipement','$criticite','$ingenieur','$idUnique','$dateCloture')";
            $res= $con->prepare($req);
            $res-> execute(); 
            if($res)
            header('Location: index.php');
                }  
                
       }   ?>

               
<div class="container " id="formback" >
    <div class="" id="formCI">
                <h2 style="text-align: center; margin-top:10px; color:#9DAA9A;">Creer votre incident </h2>
    <div class="col" >
             <form action="" method="post" name="myForm">
                  <label style="margin-left:10px;  font-weight: bold;">Intitulé de l'incident :</label>
                    <input type="text" class="form-control" name="intituleIncident" style="width: 400px; margin-left:170px;  border-color: #4d9d2a; border-width:2px; border-radius: 0.5rem;">
              <br>      <label style="margin-left:10px;font-weight: bold;">Décrivez-nous votre probléme :</label>
                  <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" type="text" name="descriptionIncident"style="width:500px;margin-left:190px; border-color: #4d9d2a;border-width:2px; border-radius: 0.5rem;"></textarea>
               <br>   <label style="margin-left:10px; font-weight: bold;">Equipement concerné:</label>
                  <select class="form-select" aria-label="Default select example" name="equipementConcerne" type="text" style="width: 300px; margin-left:200px;  border-color: #4d9d2a; border-width:2px; border-radius: 0.5rem;">
                      <option selected disabled>Open this to select equipment</option>
                      <option value="switch">switch</option>
                      <option value="modem">modem</option>
                      <option value="routeur">routeur</option>
                      <option value="ordinateur">ordinateur</option>
                      <option value="autre">Autre</option>
                  </select>
                  <?php 
 $pass = substr(str_shuffle($mot."0123456"), 0, 6);
 
 
 ?>
<input type="hidden" class="form-control" value=" <?php echo $pass; ?>" name="idUnique"  style="width: 400px; margin-left:170px;  border-color: #4d9d2a; border-width:2px; border-radius: 0.5rem;">
                  <label style="margin-left:10px; font-weight: bold;">Catégorie d'incident:</label>
                  <select class="form-select" aria-label="Default select example" type="text" name="categorieIncident" style="width: 300px; margin-left:200px;  border-color: #4d9d2a; border-width:2px; border-radius: 0.5rem;">
                      <option selected disabled>Open this to select categorie</option>
                      <option value="logiciel">logiciel</option>
                      <option value="materiel">materiel</option>
                      <option value="reseau">reseau</option>
                      <option value="autre">Autre</option>
                  </select>
                  <label  style="margin-left:10px; font-weight: bold;">Niveau de criticité :</label>
                 <p style="margin-left:150px;"> Mineur  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Majeur    
                 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Critique</p>
                  <input type="range" class="form-range" min="1" max="3" step="1"  name="niveauCriticite" id="customRange3" style="width: 400px; margin-left:150px;  ">
                 <br> <button  type="submit" onclick="return isEmpty()" class="btn btn-secondary button" name="valide" style="margin-left:900px; background-color: #4d9d2a; height: 35px; width: 90px;border-radius:0.9rem;" > Creer</button>  
          </form>
                    
     </div>
    </div>
</div>
</div>
        

             
<header style="position:fixed;">
            <div class="header-item">
            <img src="Navbar/logo.png" alt="logo" class="logo-head">
                <ul >
                    <li class="profil">
                        <span class="navbar-title-head">
                        <?php
                            $rep=$con->query("select image from image where idClient='$idClient'");
                    while($row=$rep->fetch()){
                     echo '<img  style=" width: 100px;height: 40px;  border-radius:2rem;    " src="'.$row['image'].'" >';
                    }

      ?>
                        </span>
                    </li>
                </ul>
            </div>
        </header>
        <nav class="navbar" style="position:fixed;">
            <ul class="navbar-menu">
                <li class="navbar-items logo">
                    <a href="#" class="navbar-link">
                        <span class="navbar-title">
                        <?php
                             $rep=$con->query("select image from image where idClient='$idClient'");
                             while($row=$rep->fetch()){
                              echo '<img  style=" width: 100px;height: 60px;  border-radius:2rem;    " src="'.$row['image'].'" >';
                             }
                        ?>
                        </span>
                        <i class="fas fa-chevron-right navbar-icon"></i>    
                    </a>
                </li>
                <li class="navbar-items">
                    <a href="index.php" class="navbar-link">
                        <i class="fas fa-home navbar-icon"></i>
                        <span class="navbar-title">Accueil</span>
                    </a>
                </li>
                <li class="navbar-items">
                    <a href="rechercher.php" class="navbar-link">
                        <i class="fas fa-search navbar-icon"></i>
                        <span class="navbar-title">Rechercher</span>
                    </a>
                </li>
                <li class="navbar-items">
                    <a href="formCI.php" class="navbar-link">
                        <i class="fas fa-edit navbar-icon"></i>
                        <span class="navbar-title">Créer incident</span>
                    </a>
                </li> 
             
                <li class="navbar-items">
                    <a href="../index.php" class="navbar-link">
                        <i class="fas fa-sign-out-alt navbar-icon"></i>
                        <span class="navbar-title">Deconnexion</span>
                    </a>
                </li>
            </ul>
        </nav>

                        
</body>
    </html>

